#pragma once

#include "classifier_interface.h"
#include <vector>

namespace packet_rush {

/**
 * High-Performance Packet Classifier (Participant Starter Implementation)
 * 
 * Implement your custom data structures and packet matching algorithms here.
 * The architecture is completely open — you may use bit-vector algorithms,
 * decision trees, multi-field tries, SIMD vectorization, or custom hybrid indices.
 * 
 * All code must satisfy the IPacketClassifier interface and constraints.
 */
class OptimizedClassifier : public IPacketClassifier {
public:
    OptimizedClassifier();
    ~OptimizedClassifier() override;

    void initialize(const std::vector<Rule>& rules) override;
    Action classify(const Packet& packet) override;
    void classify_batch(const Packet* packets, size_t count, Action* out_actions) override;
    void insert_rule(const Rule& rule) override;
    void delete_rule(uint32_t rule_id) override;

    const char* name() const override { return "OptimizedClassifier"; }

private:
    std::vector<Rule> rules_;
};

} // namespace packet_rush
