#include "classifier.h"
#include <algorithm>

namespace packet_rush {

OptimizedClassifier::OptimizedClassifier() = default;
OptimizedClassifier::~OptimizedClassifier() = default;

void OptimizedClassifier::initialize(const std::vector<Rule>& rules) {
    rules_ = rules;
    std::sort(rules_.begin(), rules_.end(), [](const Rule& a, const Rule& b) {
        if (a.priority != b.priority) return a.priority < b.priority;
        return a.rule_id < b.rule_id;
    });

    // TODO: Build your optimized lookup structures, tries, or SIMD layouts here.
}

Action OptimizedClassifier::classify(const Packet& packet) {
    // TODO: Replace this O(N) fallback with your sub-microsecond lookup algorithm!
    for (const auto& rule : rules_) {
        if (rule.matches(packet)) {
            return rule.action;
        }
    }
    return Action::DROP;
}

void OptimizedClassifier::classify_batch(const Packet* packets, size_t count, Action* out_actions) {
    // TODO: Leverage SIMD vectorization, prefetching, or batch pipeline optimizations here!
    for (size_t i = 0; i < count; ++i) {
        out_actions[i] = classify(packets[i]);
    }
}

void OptimizedClassifier::insert_rule(const Rule& rule) {
    // TODO: Update your internal index structures dynamically without complete rebuilds!
    auto it = std::find_if(rules_.begin(), rules_.end(), [&](const Rule& r) {
        return r.rule_id == rule.rule_id;
    });
    if (it != rules_.end()) {
        rules_.erase(it);
    }
    auto insert_pos = std::lower_bound(rules_.begin(), rules_.end(), rule, [](const Rule& a, const Rule& b) {
        if (a.priority != b.priority) return a.priority < b.priority;
        return a.rule_id < b.rule_id;
    });
    rules_.insert(insert_pos, rule);
}

void OptimizedClassifier::delete_rule(uint32_t rule_id) {
    // TODO: Remove rule from your internal lookup indices dynamically!
    auto it = std::find_if(rules_.begin(), rules_.end(), [&](const Rule& r) {
        return r.rule_id == rule_id;
    });
    if (it != rules_.end()) {
        rules_.erase(it);
    }
}

} // namespace packet_rush
